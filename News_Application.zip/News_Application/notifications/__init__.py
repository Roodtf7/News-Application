"""
Initialization for the notifications application package.
"""
