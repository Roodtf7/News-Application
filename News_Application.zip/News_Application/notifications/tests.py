"""
Tests for the notifications application.
Verifies that signals correctly trigger email and 3rd-party platform notifications on approval.
"""
from django.test import TestCase

# Create your tests here.
