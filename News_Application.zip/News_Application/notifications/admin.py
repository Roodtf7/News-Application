"""
Admin configuration for the notifications application.
Registers notification-related models to the Django admin panel if necessary.
"""
from django.contrib import admin

# Register your models here.
