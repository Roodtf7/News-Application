"""
Models for the notifications application.
Currently acts as a placeholder or stores notification history if implemented.
"""
from django.db import models

# Create your models here.
