"""
Views for the notifications application.
Provides endpoints for managing user notification preferences if required.
"""
from django.shortcuts import render

# Create your views here.
