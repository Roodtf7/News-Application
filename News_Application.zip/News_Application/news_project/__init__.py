"""
Initialization for the news_project configuration package.
"""
