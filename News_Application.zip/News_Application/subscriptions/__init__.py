"""
Initialization for the subscriptions application package.
"""
