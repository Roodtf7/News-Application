"""
Initialization for the publishers application package.
"""
