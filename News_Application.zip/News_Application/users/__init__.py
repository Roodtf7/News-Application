"""
Initialization for the users application package.
"""
