"""
Initialization for the articles application package.
"""
