"""
Admin configuration for the API application.
Defines how API-related models (if any) are displayed in the Django admin interface.
"""
from django.contrib import admin

# Register your models here.
