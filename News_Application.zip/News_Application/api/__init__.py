"""
Initialization for the API package.
"""
