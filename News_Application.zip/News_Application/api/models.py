"""
Models for the API application.
Stored data specifically required for the API layer that is not part of the core articles or users.
"""
from django.db import models

# Create your models here.
